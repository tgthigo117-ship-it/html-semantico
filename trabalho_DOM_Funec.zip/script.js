// Manipulação do DOM

// getElementById
let texto = document.getElementById("texto");

// getElementsByClassName
let destaque = document.getElementsByClassName("destaque");

// getElementsByTagName
let paragrafos = document.getElementsByTagName("p");

// querySelector
let titulo = document.querySelector("h1");

// querySelectorAll
let caixas = document.querySelectorAll("article");

// innerHTML
texto.innerHTML = "Este é um parágrafo que será utilizado nos exercícios.";

// addEventListener
let botao = document.getElementById("botaoPrincipal");

botao.addEventListener("click", function () {
    alert("Botão principal clicado!");
});

// classList.toggle(class)
botao.addEventListener("click", function () {
    destaque[0].classList.toggle("destaque");
});

// createElement
let novoParagrafo = document.createElement("p");
novoParagrafo.innerHTML = "Elemento criado pelo JavaScript.";

// appendChild
document.querySelector("main").appendChild(novoParagrafo);

// Evento nas caixas
caixas.forEach(function (caixa) {
    caixa.addEventListener("click", function () {
        caixa.classList.toggle("destaque");
    });
});

// Evita o formulário recarregar a página
document.getElementById("formulario").addEventListener("submit", function (evento) {
    evento.preventDefault();
    alert("Formulário enviado!");
});
